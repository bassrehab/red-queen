//! Red Queen CLI
//!
//! Command-line interface for running evolutionary adversarial testing.

use std::fs::File;
use std::io::Write;
use std::sync::Arc;

use anyhow::{anyhow, Context, Result};
use clap::{Parser, Subcommand};
use indicatif::{ProgressBar, ProgressStyle};
use serde::{Deserialize, Serialize};

use evo_core::archive::{Archive, BehaviorDimension, MapElitesArchive};
use evo_core::evolution::{Evolution, EvolutionConfig, MapElitesConfig, MapElitesEvolution};
use evo_core::population::PopulationConfig;
use evo_core::selection::{NoveltyArchive, NoveltyFitnessSelection, NoveltySelection, Tournament};
use evo_core::variation::VariationConfig;
use std::sync::RwLock;
use evo_llm::fitness::{EvaluationRecord, JailbreakFitness, JudgeMode, JudgedJailbreakFitness};
use evo_llm::genome::LLMAttackGenome;
use evo_llm::judge::JudgeResult;
use evo_llm::seeds::{self, SeedPool};
use evo_llm::targets::{AnthropicTarget, GeminiTarget, LLMTarget, MockTarget, OllamaTarget, OpenAITarget};

#[derive(Parser)]
#[command(name = "evo-safety")]
#[command(about = "Evolutionary adversarial testing framework")]
#[command(version)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// LLM safety domain commands
    Llm {
        #[command(subcommand)]
        action: LlmCommands,
    },
    /// Analyze results from a previous run
    Analyze {
        /// Path to results file
        #[arg(short, long)]
        input: String,
    },
}

#[derive(Subcommand)]
enum LlmCommands {
    /// Discover jailbreaks through evolution
    Jailbreak {
        /// Target model. Formats:
        ///   openai:gpt-4             - OpenAI GPT-4
        ///   anthropic:claude-sonnet-4-20250514 - Anthropic Claude
        ///   gemini:gemini-2.0-flash  - Google Gemini
        ///   huggingface:google/gemma-7b-it - HuggingFace router (OpenAI-compatible)
        ///   openai-compat:model@http://host:port - Any OpenAI-compatible endpoint (vLLM, TGI, etc.)
        ///   ollama:llama3.2          - Local Ollama model
        ///   mock:refuse              - Mock target (always refuses)
        ///   mock:comply              - Mock target (always complies)
        #[arg(short, long)]
        target: String,

        /// Number of generations to evolve
        #[arg(short, long, default_value = "100")]
        generations: usize,

        /// Population size
        #[arg(short, long, default_value = "50")]
        population: usize,

        /// Tournament selection size
        #[arg(long, default_value = "3")]
        tournament_size: usize,

        /// Mutation rate (0.0 to 1.0)
        #[arg(long, default_value = "0.3")]
        mutation_rate: f64,

        /// Crossover rate (0.0 to 1.0)
        #[arg(long, default_value = "0.7")]
        crossover_rate: f64,

        /// Random seed for reproducibility (optional)
        #[arg(long)]
        seed: Option<u64>,

        /// Output file for results
        #[arg(short, long, default_value = "results.json")]
        output: String,

        /// Verbose output
        #[arg(short, long)]
        verbose: bool,

        /// Use LLM judge for accurate fitness evaluation.
        /// Specify the judge model (e.g., openai:gpt-4o-mini, anthropic:claude-3-haiku-20240307)
        #[arg(long)]
        judge: Option<String>,

        /// Store all responses for later analysis
        #[arg(long)]
        store_responses: bool,

        /// Use MAP-Elites quality-diversity algorithm instead of standard evolution.
        /// This maintains diversity across behavior dimensions (strategy, encoding, prompt length).
        #[arg(long)]
        map_elites: bool,

        /// Number of bins per behavior dimension for MAP-Elites (default: 10)
        #[arg(long, default_value = "10")]
        me_bins: usize,

        /// Batch size for MAP-Elites (offspring per generation, default: 50)
        #[arg(long, default_value = "50")]
        me_batch_size: usize,

        /// Use novelty-based selection. Selects individuals based on behavioral uniqueness.
        /// Can be combined with fitness using --novelty-weight.
        #[arg(long)]
        novelty: bool,

        /// Weight for fitness vs novelty (0.0 = pure novelty, 1.0 = pure fitness).
        /// Only used when --novelty is enabled.
        #[arg(long, default_value = "0.5")]
        novelty_weight: f64,

        /// Number of nearest neighbors for novelty computation (default: 15)
        #[arg(long, default_value = "15")]
        novelty_k: usize,

        /// Maximum concurrent API calls for parallel evaluation (default: 10).
        /// Higher values speed up evolution but may hit API rate limits.
        #[arg(long, default_value = "10")]
        concurrency: usize,

        /// Path to a JSONL file of seed behaviors (e.g. HarmBench, AdvBench).
        /// Each line must be a JSON object with fields:
        ///   {"id": "...", "behavior": "...", "category": "...", "tags": []}
        /// When provided, initial genomes draw their core from this pool
        /// instead of the generic placeholder. The file is read from disk
        /// and is never embedded in the crate — bring your own dataset.
        #[arg(long)]
        seeds: Option<String>,
    },

    /// Replay a saved MAP-Elites archive against a different target model.
    /// Used for cross-generational transfer analysis.
    Transfer {
        /// Path to a saved archive JSON (from a previous MAP-Elites run).
        #[arg(short, long)]
        archive: String,

        /// Target model to replay against (same formats as jailbreak --target).
        #[arg(short, long)]
        target: String,

        /// LLM judge for scoring (e.g., openai:gpt-5.4-mini).
        /// Defaults to heuristic if not specified.
        #[arg(long)]
        judge: Option<String>,

        /// Maximum concurrent API calls (default: 5).
        #[arg(long, default_value = "5")]
        concurrency: usize,

        /// Output file for transfer results.
        #[arg(short, long, default_value = "transfer_results.json")]
        output: String,
    },
}

/// Parse target string into an LLMTarget.
fn parse_target(target_str: &str) -> Result<Arc<dyn LLMTarget>> {
    // Handle prefixes that contain URLs or complex model IDs with colons
    // before falling through to the simple split(':') path.

    if let Some(model) = target_str.strip_prefix("huggingface:") {
        if model.is_empty() {
            return Err(anyhow!("Empty HuggingFace model ID in target '{}'", target_str));
        }
        let target = OpenAITarget::huggingface_from_env(model)
            .context("Failed to create HuggingFace target. Is HUGGINGFACE_TOKEN_QAA set?")?;
        return Ok(Arc::new(target));
    }

    // openai-compat:MODEL@BASE_URL — any OpenAI-compatible endpoint (vLLM, TGI, etc.).
    // API key read from OPENAI_COMPAT_API_KEY; defaults to "none" (most local endpoints need no auth).
    if let Some(rest) = target_str.strip_prefix("openai-compat:") {
        let (model, base_url) = rest.rsplit_once('@').ok_or_else(|| {
            anyhow!(
                "Invalid openai-compat target '{}'. Expected format: openai-compat:MODEL@BASE_URL",
                target_str
            )
        })?;
        if model.is_empty() || base_url.is_empty() {
            return Err(anyhow!(
                "Both model and base URL are required. Format: openai-compat:MODEL@BASE_URL"
            ));
        }
        let api_key = std::env::var("OPENAI_COMPAT_API_KEY").unwrap_or_else(|_| "none".to_string());
        let target = OpenAITarget::with_base_url(model, &api_key, base_url);
        return Ok(Arc::new(target));
    }

    let parts: Vec<&str> = target_str.split(':').collect();

    match parts.as_slice() {
        ["mock", "refuse"] | ["mock"] => Ok(Arc::new(MockTarget::always_refuse())),
        ["mock", "comply"] => Ok(Arc::new(MockTarget::always_comply())),
        ["openai", model] => {
            let target = OpenAITarget::from_env(model)
                .context("Failed to create OpenAI target. Is OPENAI_API_KEY set?")?;
            Ok(Arc::new(target))
        }
        ["anthropic", model] => {
            let target = AnthropicTarget::from_env(model)
                .context("Failed to create Anthropic target. Is ANTHROPIC_API_KEY set?")?;
            Ok(Arc::new(target))
        }
        ["gemini", model] => {
            let target = GeminiTarget::from_env(model)
                .context("Failed to create Gemini target. Is GOOGLE_API_KEY set?")?;
            Ok(Arc::new(target))
        }
        ["ollama", model] => {
            let target = OllamaTarget::from_env(model);
            Ok(Arc::new(target))
        }
        _ => Err(anyhow!(
            "Unknown target: '{}'. Use 'openai:', 'anthropic:', 'gemini:', 'huggingface:', 'openai-compat:', 'ollama:', or 'mock:'",
            target_str
        )),
    }
}

/// Serializable judge result.
#[derive(Debug, Serialize, Deserialize)]
struct SerializableJudgeResult {
    score: f64,
    refused: bool,
    harmful_content: bool,
    relevant: bool,
    explanation: String,
}

impl From<&JudgeResult> for SerializableJudgeResult {
    fn from(jr: &JudgeResult) -> Self {
        Self {
            score: jr.score,
            refused: jr.refused,
            harmful_content: jr.harmful_content,
            relevant: jr.relevant,
            explanation: jr.explanation.clone(),
        }
    }
}

/// Result entry for a single attack.
#[derive(Debug, Serialize, Deserialize)]
struct AttackResult {
    strategy: String,
    encoding: String,
    secondary_strategy: Option<String>,
    fitness: f64,
    prompt: String,
    generation: usize,
    /// Originating seed behavior id, if the genome was seeded.
    #[serde(skip_serializing_if = "Option::is_none")]
    seed_id: Option<String>,
    /// Originating seed category, if known.
    #[serde(skip_serializing_if = "Option::is_none")]
    seed_category: Option<String>,
    /// Response from target (if stored).
    #[serde(skip_serializing_if = "Option::is_none")]
    response: Option<String>,
    /// Judge evaluation (if using LLM judge).
    #[serde(skip_serializing_if = "Option::is_none")]
    judge_result: Option<SerializableJudgeResult>,
}

/// Per-category summary statistics.
#[derive(Debug, Serialize, Deserialize)]
struct CategorySummary {
    total_attacks: usize,
    successful_attacks: usize,
    success_rate: f64,
    best_fitness: f64,
    best_strategy: String,
    avg_fitness: f64,
}

/// Full results from an evolution run.
#[derive(Debug, Serialize, Deserialize)]
struct EvolutionResults {
    target: String,
    generations: usize,
    population_size: usize,
    best_attack: AttackResult,
    top_attacks: Vec<AttackResult>,
    #[serde(skip_serializing_if = "Option::is_none")]
    category_summary: Option<std::collections::BTreeMap<String, CategorySummary>>,
    config: RunConfig,
}

/// A single entry in an exported MAP-Elites archive.
/// Contains everything needed for transfer replay against a different model.
#[derive(Debug, Serialize, Deserialize)]
struct ArchiveEntry {
    /// Behavior-space cell coordinates (e.g. [strategy_bin, encoding_bin, category_bin]).
    cell: Vec<f64>,
    strategy: String,
    encoding: String,
    fitness: f64,
    prompt: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    seed_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    seed_category: Option<String>,
    birth_generation: usize,
}

/// Full exported archive for cross-model transfer replay.
#[derive(Debug, Serialize, Deserialize)]
struct ExportedArchive {
    target: String,
    generations: usize,
    total_cells: usize,
    filled_cells: usize,
    entries: Vec<ArchiveEntry>,
}

#[derive(Debug, Serialize, Deserialize)]
struct RunConfig {
    mutation_rate: f64,
    crossover_rate: f64,
    tournament_size: usize,
    seed: Option<u64>,
}

fn genome_to_result(
    genome: &LLMAttackGenome,
    fitness: f64,
    generation: usize,
    response: Option<String>,
    judge_result: Option<&JudgeResult>,
) -> AttackResult {
    AttackResult {
        strategy: format!("{:?}", genome.primary_strategy),
        encoding: format!("{:?}", genome.encoding),
        secondary_strategy: genome.secondary_strategy.as_ref().map(|s| format!("{:?}", s)),
        fitness,
        prompt: genome.to_prompt(),
        generation,
        seed_id: genome.seed_id.clone(),
        seed_category: genome.seed_category.clone(),
        response,
        judge_result: judge_result.map(SerializableJudgeResult::from),
    }
}

/// Coverage info for MAP-Elites results.
struct CoverageInfo {
    filled: usize,
    total: usize,
    percentage: f64,
}

/// Run MAP-Elites quality-diversity evolution.
#[allow(clippy::too_many_arguments)]
fn run_map_elites_evolution(
    target: Arc<dyn LLMTarget>,
    judge_mode: JudgeMode,
    generations: usize,
    bins: usize,
    batch_size: usize,
    mutation_rate: f64,
    crossover_rate: f64,
    seed: Option<u64>,
    store_responses: bool,
    concurrency: usize,
    has_seeds: bool,
    pb: &ProgressBar,
) -> Result<(LLMAttackGenome, f64, Vec<AttackResult>, Vec<EvaluationRecord>, Option<CoverageInfo>, Vec<ArchiveEntry>)> {
    use evo_llm::genome::SEED_CATEGORY_COUNT;

    // Create behavior dimensions for LLM attacks:
    // Dim 0: Strategy (0-5, 6 variants)
    // Dim 1: Encoding (0-5, 6 variants)
    // Dim 2: When seeds are provided, use seed_category index (0-7, 7 known + 1 catch-all).
    //        Otherwise fall back to prompt length.
    let dim2 = if has_seeds {
        BehaviorDimension {
            name: "seed_category".to_string(),
            min: 0.0,
            max: (SEED_CATEGORY_COUNT + 1) as f64,
            bins: SEED_CATEGORY_COUNT + 1,
        }
    } else {
        BehaviorDimension {
            name: "prompt_length".to_string(),
            min: 0.0,
            max: 2000.0,
            bins,
        }
    };

    let dimensions = vec![
        BehaviorDimension {
            name: "strategy".to_string(),
            min: 0.0,
            max: 6.0,
            bins,
        },
        BehaviorDimension {
            name: "encoding".to_string(),
            min: 0.0,
            max: 6.0,
            bins,
        },
        dim2,
    ];

    let archive = MapElitesArchive::new(dimensions);

    // Use JudgedJailbreakFitness for MAP-Elites (always stores responses for diversity analysis)
    let mut fitness = JudgedJailbreakFitness::new(target, judge_mode)
        .with_concurrency(concurrency);
    if has_seeds {
        fitness = fitness.with_seed_category_dimension();
    }

    let config = MapElitesConfig {
        batch_size,
        variation: VariationConfig {
            mutation_rate,
            crossover_rate,
        },
        seed,
        initial_population: batch_size,
    };

    let mut evolution = MapElitesEvolution::new(archive, &fitness, config);

    // Run evolution with progress updates
    for _ in 0..generations {
        evolution.step();
        pb.inc(1);
    }
    pb.finish_with_message("complete");

    // Get results from archive
    let archive = evolution.archive();
    let coverage = archive.coverage();

    let best = archive.best().cloned().ok_or_else(|| {
        anyhow!("MAP-Elites archive is empty after evolution")
    })?;
    let best_genome = best.genome.clone();
    let best_fitness = best.fitness_value();

    // Get diverse top attacks from archive
    let top: Vec<AttackResult> = archive
        .top_n(10)
        .iter()
        .map(|ind| {
            genome_to_result(
                &ind.genome,
                ind.fitness_value(),
                ind.birth_generation,
                None,
                None,
            )
        })
        .collect();

    let records = if store_responses {
        fitness.get_top_records(100)
    } else {
        vec![]
    };

    let coverage_info = CoverageInfo {
        filled: coverage.filled,
        total: coverage.total,
        percentage: coverage.percentage() * 100.0,
    };

    let archive_entries: Vec<ArchiveEntry> = archive
        .get_all()
        .iter()
        .map(|ind| {
            let behavior_values = ind
                .behavior
                .as_ref()
                .map(|b| b.values.clone())
                .unwrap_or_default();
            ArchiveEntry {
                cell: behavior_values,
                strategy: format!("{:?}", ind.genome.primary_strategy),
                encoding: format!("{:?}", ind.genome.encoding),
                fitness: ind.fitness_value(),
                prompt: ind.genome.to_prompt(),
                seed_id: ind.genome.seed_id.clone(),
                seed_category: ind.genome.seed_category.clone(),
                birth_generation: ind.birth_generation,
            }
        })
        .collect();

    Ok((best_genome, best_fitness, top, records, Some(coverage_info), archive_entries))
}

#[allow(clippy::too_many_arguments)]
fn run_jailbreak_evolution(
    target_str: &str,
    generations: usize,
    population: usize,
    tournament_size: usize,
    mutation_rate: f64,
    crossover_rate: f64,
    seed: Option<u64>,
    output: &str,
    verbose: bool,
    judge_str: Option<&str>,
    store_responses: bool,
    map_elites: bool,
    me_bins: usize,
    me_batch_size: usize,
    novelty: bool,
    novelty_weight: f64,
    novelty_k: usize,
    concurrency: usize,
    seeds_path: Option<&str>,
) -> Result<()> {
    println!();
    println!("  Red Queen - LLM Jailbreak Discovery");
    println!("  ====================================");
    println!();

    // Parse target
    let target = parse_target(target_str)?;
    println!("  Target:       {}", target_str);
    println!("  Generations:  {}", generations);
    println!("  Population:   {}", population);
    println!("  Tournament:   {}", tournament_size);
    println!("  Mutation:     {:.1}%", mutation_rate * 100.0);
    println!("  Crossover:    {:.1}%", crossover_rate * 100.0);
    if let Some(s) = seed {
        println!("  Seed:         {}", s);
    }
    println!("  Output:       {}", output);

    // Load and install seed pool if the user supplied one.
    if let Some(path) = seeds_path {
        let pool = SeedPool::from_jsonl_path(path)
            .with_context(|| format!("Failed to load seed pool from {}", path))?;
        if pool.is_empty() {
            return Err(anyhow!("Seed file {} contains no behaviors", path));
        }
        println!("  Seeds:        {} ({} behaviors)", path, pool.len());
        let counts = pool.category_counts();
        if !counts.is_empty() {
            println!("  Categories:");
            for (cat, n) in &counts {
                println!("    - {:<32} {}", cat, n);
            }
        }
        seeds::install_seed_pool(pool);
    } else {
        println!("  Seeds:        <none> (using generic placeholder)");
    }

    // Determine fitness evaluator mode
    let use_judge = judge_str.is_some() || store_responses;
    let judge_mode = if let Some(judge_model_str) = judge_str {
        let judge_model = parse_target(judge_model_str)?;
        println!("  Judge:        {} (LLM)", judge_model_str);
        JudgeMode::LLM(judge_model)
    } else {
        println!("  Judge:        Heuristic (fast)");
        JudgeMode::Heuristic
    };

    if store_responses {
        println!("  Responses:    Stored for analysis");
    }
    println!("  Concurrency:  {} parallel evaluations", concurrency);
    if map_elites {
        println!("  Algorithm:    MAP-Elites (QD)");
        println!("  Bins:         {} per dimension", me_bins);
        println!("  Batch size:   {}", me_batch_size);
    } else if novelty {
        println!("  Algorithm:    Novelty Search");
        println!("  Novelty k:    {}", novelty_k);
        println!("  Fit weight:   {:.0}%", novelty_weight * 100.0);
    } else {
        println!("  Algorithm:    Standard Evolution");
    }
    println!();

    // Configure evolution
    let config = EvolutionConfig {
        population: PopulationConfig {
            size: population,
            elitism: (population / 10).max(1), // 10% elitism
        },
        variation: VariationConfig {
            mutation_rate,
            crossover_rate,
        },
        seed,
    };

    // Set up progress bar
    let pb = ProgressBar::new(generations as u64);
    pb.set_style(
        ProgressStyle::default_bar()
            .template("  [{elapsed_precise}] [{bar:40.cyan/blue}] {pos}/{len} generations")
            .unwrap()
            .progress_chars("#>-"),
    );

    println!("  Starting evolution...");
    println!();

    // Run evolution - choose algorithm based on flags
    let (best_genome, best_fitness, top_attacks, stored_records, coverage_info, archive_entries) = if map_elites {
        // MAP-Elites quality-diversity evolution
        run_map_elites_evolution(
            target.clone(),
            judge_mode,
            generations,
            me_bins,
            me_batch_size,
            mutation_rate,
            crossover_rate,
            seed,
            store_responses,
            concurrency,
            seeds_path.is_some(),
            &pb,
        )?
    } else if novelty {
        // Novelty-based selection (combined with fitness)
        let novelty_archive = Arc::new(RwLock::new(NoveltyArchive::new(1000, 0.1)));
        let novelty_sel = NoveltySelection::new(novelty_k, tournament_size, novelty_archive);
        let selection = NoveltyFitnessSelection::new(novelty_sel, novelty_weight);

        let mut fitness = JudgedJailbreakFitness::new(target.clone(), judge_mode)
            .with_concurrency(concurrency);
        if seeds_path.is_some() {
            fitness = fitness.with_seed_category_dimension();
        }
        let mut evolution: Evolution<LLMAttackGenome, _, _> =
            Evolution::new(&fitness, selection, config);

        let result = evolution.run(generations);
        pb.finish_with_message("complete");

        let best = &result.best;
        let best_fitness_val = best.fitness.as_ref().map(|f| f.primary()).unwrap_or(0.0);

        let top: Vec<AttackResult> = result
            .population
            .top_n(10)
            .iter()
            .map(|ind| {
                genome_to_result(
                    &ind.genome,
                    ind.fitness_value(),
                    ind.birth_generation,
                    None,
                    None,
                )
            })
            .collect();

        let records = if store_responses {
            fitness.get_top_records(100)
        } else {
            vec![]
        };

        (best.genome.clone(), best_fitness_val, top, records, None, vec![])
    } else if use_judge {
        // Standard evolution with judged fitness
        let selection = Tournament::new(tournament_size);
        let mut fitness = JudgedJailbreakFitness::new(target.clone(), judge_mode)
            .with_concurrency(concurrency);
        if seeds_path.is_some() {
            fitness = fitness.with_seed_category_dimension();
        }
        let mut evolution: Evolution<LLMAttackGenome, _, _> =
            Evolution::new(&fitness, selection, config);

        let result = evolution.run(generations);
        pb.finish_with_message("complete");

        let best = &result.best;
        let best_fitness_val = best.fitness.as_ref().map(|f| f.primary()).unwrap_or(0.0);

        let top: Vec<AttackResult> = result
            .population
            .top_n(10)
            .iter()
            .map(|ind| {
                genome_to_result(
                    &ind.genome,
                    ind.fitness_value(),
                    ind.birth_generation,
                    None,
                    None,
                )
            })
            .collect();

        let records = if store_responses {
            fitness.get_top_records(100)
        } else {
            vec![]
        };

        (best.genome.clone(), best_fitness_val, top, records, None, vec![])
    } else {
        // Standard evolution with simple heuristic fitness
        let selection = Tournament::new(tournament_size);
        let fitness = JailbreakFitness::new(target.clone())
            .with_concurrency(concurrency);
        let mut evolution: Evolution<LLMAttackGenome, _, _> =
            Evolution::new(fitness, selection, config);

        let result = evolution.run(generations);
        pb.finish_with_message("complete");

        let best = &result.best;
        let best_fitness_val = best.fitness.as_ref().map(|f| f.primary()).unwrap_or(0.0);

        let top: Vec<AttackResult> = result
            .population
            .top_n(10)
            .iter()
            .map(|ind| {
                genome_to_result(
                    &ind.genome,
                    ind.fitness_value(),
                    ind.birth_generation,
                    None,
                    None,
                )
            })
            .collect();

        (best.genome.clone(), best_fitness_val, top, vec![], None, vec![])
    };
    println!();

    println!("  Results");
    println!("  -------");
    println!();

    // Show coverage info for MAP-Elites
    if let Some(cov) = &coverage_info {
        println!("  Coverage:     {}/{} cells ({:.1}%)", cov.filled, cov.total, cov.percentage);
        println!();
    }

    println!("  Best fitness: {:.2}", best_fitness);
    println!("  Strategy:     {:?}", best_genome.primary_strategy);
    println!("  Encoding:     {:?}", best_genome.encoding);
    println!();

    if verbose {
        println!("  Best prompt:");
        println!("  ---");
        for line in best_genome.to_prompt().lines() {
            println!("  {}", line);
        }
        println!("  ---");
        println!();
    }

    // Enrich top attacks with responses if we have stored records
    let mut top_attacks = top_attacks;
    if !stored_records.is_empty() {
        // Create a lookup map from prompt to record
        let record_map: std::collections::HashMap<String, &EvaluationRecord> = stored_records
            .iter()
            .map(|r| (r.prompt.clone(), r))
            .collect();

        // Enrich top attacks with response data
        // Use the record's fitness to ensure consistency with judge_result
        for attack in &mut top_attacks {
            if let Some(record) = record_map.get(&attack.prompt) {
                attack.response = Some(record.response.clone());
                attack.judge_result = record.judge_result.as_ref().map(SerializableJudgeResult::from);
                // Use record's fitness for consistency with judge_result
                attack.fitness = record.fitness;
            }
        }
    }

    println!("  Top 10 attacks:");
    for (i, attack) in top_attacks.iter().enumerate() {
        let judge_info = attack.judge_result.as_ref()
            .map(|jr| format!(" [refused={}, harmful={}]", jr.refused, jr.harmful_content))
            .unwrap_or_default();
        println!(
            "    {}. {} / {} - fitness: {:.2}{}",
            i + 1,
            attack.strategy,
            attack.encoding,
            attack.fitness,
            judge_info
        );
    }
    println!();

    // Compute per-category summary from archive entries (when seeds are used)
    let category_summary = if !archive_entries.is_empty() {
        let mut cat_data: std::collections::BTreeMap<String, (usize, usize, f64, f64, String)> =
            std::collections::BTreeMap::new();
        for entry in &archive_entries {
            let cat = entry.seed_category.clone().unwrap_or_else(|| "unknown".to_string());
            let (total, success, fitness_sum, best_fit, best_strat) =
                cat_data.entry(cat).or_insert((0, 0, 0.0, 0.0, String::new()));
            *total += 1;
            *fitness_sum += entry.fitness;
            if entry.fitness > 0.0 { *success += 1; }
            if entry.fitness > *best_fit {
                *best_fit = entry.fitness;
                *best_strat = entry.strategy.clone();
            }
        }
        let summary: std::collections::BTreeMap<String, CategorySummary> = cat_data
            .into_iter()
            .map(|(cat, (total, success, fitness_sum, best_fit, best_strat))| {
                (cat, CategorySummary {
                    total_attacks: total,
                    successful_attacks: success,
                    success_rate: if total > 0 { success as f64 / total as f64 } else { 0.0 },
                    best_fitness: best_fit,
                    best_strategy: best_strat,
                    avg_fitness: if total > 0 { fitness_sum / total as f64 } else { 0.0 },
                })
            })
            .collect();

        println!("  Category Summary:");
        for (cat, cs) in &summary {
            println!("    {:<32} {}/{} ({:.1}%)  best={:.2} ({})",
                cat, cs.successful_attacks, cs.total_attacks, cs.success_rate * 100.0,
                cs.best_fitness, cs.best_strategy);
        }
        println!();
        Some(summary)
    } else {
        None
    };

    // Build results structure
    let results = EvolutionResults {
        target: target_str.to_string(),
        generations,
        population_size: population,
        best_attack: genome_to_result(&best_genome, best_fitness, 0, None, None),
        top_attacks,
        category_summary,
        config: RunConfig {
            mutation_rate,
            crossover_rate,
            tournament_size,
            seed,
        },
    };

    // Export to JSON
    let json = serde_json::to_string_pretty(&results)?;
    let mut file = File::create(output)?;
    file.write_all(json.as_bytes())?;
    println!("  Results saved to: {}", output);

    // Export full MAP-Elites archive for transfer replay
    if !archive_entries.is_empty() {
        let archive_path = output.replace(".json", "_archive.json");
        let exported = ExportedArchive {
            target: target_str.to_string(),
            generations,
            total_cells: coverage_info.as_ref().map(|c| c.total).unwrap_or(0),
            filled_cells: archive_entries.len(),
            entries: archive_entries,
        };
        let archive_json = serde_json::to_string_pretty(&exported)?;
        let mut archive_file = File::create(&archive_path)?;
        archive_file.write_all(archive_json.as_bytes())?;
        println!("  Archive saved to: {} ({} entries)", archive_path, exported.filled_cells);
    }
    println!();

    Ok(())
}

fn analyze_results(input: &str) -> Result<()> {
    println!();
    println!("  Red Queen - Results Analysis");
    println!("  =============================");
    println!();

    // Read results file
    let content = std::fs::read_to_string(input)
        .with_context(|| format!("Failed to read file: {}", input))?;

    let results: EvolutionResults = serde_json::from_str(&content)
        .with_context(|| format!("Failed to parse results file: {}", input))?;

    println!("  Target:       {}", results.target);
    println!("  Generations:  {}", results.generations);
    println!("  Population:   {}", results.population_size);
    println!();
    println!("  Best Attack");
    println!("  -----------");
    println!("  Fitness:      {:.2}", results.best_attack.fitness);
    println!("  Strategy:     {}", results.best_attack.strategy);
    println!("  Encoding:     {}", results.best_attack.encoding);
    println!();
    println!("  Prompt:");
    println!("  ---");
    for line in results.best_attack.prompt.lines() {
        println!("  {}", line);
    }
    println!("  ---");
    println!();

    // Strategy distribution
    let mut strategy_counts: std::collections::HashMap<&str, usize> =
        std::collections::HashMap::new();
    for attack in &results.top_attacks {
        *strategy_counts.entry(&attack.strategy).or_insert(0) += 1;
    }

    println!("  Strategy Distribution (Top 10):");
    for (strategy, count) in strategy_counts {
        println!("    {}: {}", strategy, count);
    }
    println!();

    Ok(())
}

/// Per-category transfer statistics.
#[derive(Debug, Serialize, Deserialize)]
struct CategoryTransfer {
    total: usize,
    transferred: usize,
    rate: f64,
    avg_source_fitness: f64,
    avg_replay_fitness: f64,
}

/// Result of replaying a single archive entry against a different target.
#[derive(Debug, Serialize, Deserialize)]
struct TransferEntry {
    cell: Vec<f64>,
    strategy: String,
    encoding: String,
    source_fitness: f64,
    replay_fitness: f64,
    transferred: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    seed_category: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    judge_result: Option<SerializableJudgeResult>,
}

/// Full transfer replay results.
#[derive(Debug, Serialize, Deserialize)]
struct TransferResults {
    source_target: String,
    replay_target: String,
    source_archive_entries: usize,
    overall_success_rate: f64,
    total_transferred: usize,
    category_transfer: std::collections::BTreeMap<String, CategoryTransfer>,
    entries: Vec<TransferEntry>,
}

/// Run transfer replay: load archive, re-evaluate against a different target.
fn run_transfer_replay(
    archive_path: &str,
    target_str: &str,
    judge_str: Option<&str>,
    concurrency: usize,
    output: &str,
) -> Result<()> {
    println!();
    println!("  Red Queen - Transfer Replay");
    println!("  ===========================");
    println!();

    let content = std::fs::read_to_string(archive_path)
        .with_context(|| format!("Failed to read archive: {}", archive_path))?;
    let archive: ExportedArchive = serde_json::from_str(&content)
        .with_context(|| format!("Failed to parse archive: {}", archive_path))?;

    println!("  Source:       {}", archive.target);
    println!("  Archive:      {} entries from {} ({}/{})",
        archive.entries.len(), archive_path, archive.filled_cells, archive.total_cells);
    println!("  Replay on:    {}", target_str);

    let target = parse_target(target_str)?;

    let judge: Arc<dyn evo_llm::judge::Judge> = if let Some(judge_model_str) = judge_str {
        let judge_model = parse_target(judge_model_str)?;
        println!("  Judge:        {} (LLM)", judge_model_str);
        Arc::new(evo_llm::judge::LLMJudge::new(judge_model))
    } else {
        println!("  Judge:        Heuristic (fast)");
        Arc::new(evo_llm::judge::HeuristicJudge::new())
    };

    println!("  Concurrency:  {}", concurrency);
    println!();
    println!("  Replaying {} prompts...", archive.entries.len());

    let rt = tokio::runtime::Runtime::new()?;
    let transfer_entries: Vec<TransferEntry> = rt.block_on(async {
        use futures::stream::{self, StreamExt};

        let results: Vec<TransferEntry> = stream::iter(&archive.entries)
            .map(|entry| {
                let target = target.clone();
                let judge = judge.clone();
                async move {
                    let response = target.query(&entry.prompt).await.unwrap_or_default();
                    let judge_result = judge
                        .evaluate(&entry.prompt, &response)
                        .await
                        .unwrap_or_default();

                    let replay_fitness = judge_result.score;
                    let transferred = replay_fitness > 0.0 && !judge_result.refused;

                    TransferEntry {
                        cell: entry.cell.clone(),
                        strategy: entry.strategy.clone(),
                        encoding: entry.encoding.clone(),
                        source_fitness: entry.fitness,
                        replay_fitness,
                        transferred,
                        seed_category: entry.seed_category.clone(),
                        judge_result: Some(SerializableJudgeResult::from(&judge_result)),
                    }
                }
            })
            .buffered(concurrency)
            .collect()
            .await;
        results
    });

    let total = transfer_entries.len();
    let transferred_count = transfer_entries.iter().filter(|e| e.transferred).count();
    let overall_rate = if total > 0 { transferred_count as f64 / total as f64 } else { 0.0 };

    // Aggregate by category
    let mut category_map: std::collections::BTreeMap<String, (usize, usize, f64, f64)> =
        std::collections::BTreeMap::new();
    for entry in &transfer_entries {
        let cat = entry.seed_category.clone().unwrap_or_else(|| "unknown".to_string());
        let (total, transferred, src_sum, replay_sum) =
            category_map.entry(cat).or_insert((0, 0, 0.0, 0.0));
        *total += 1;
        if entry.transferred { *transferred += 1; }
        *src_sum += entry.source_fitness;
        *replay_sum += entry.replay_fitness;
    }

    let category_transfer: std::collections::BTreeMap<String, CategoryTransfer> = category_map
        .into_iter()
        .map(|(cat, (total, transferred, src_sum, replay_sum))| {
            let rate = if total > 0 { transferred as f64 / total as f64 } else { 0.0 };
            (cat, CategoryTransfer {
                total,
                transferred,
                rate,
                avg_source_fitness: if total > 0 { src_sum / total as f64 } else { 0.0 },
                avg_replay_fitness: if total > 0 { replay_sum / total as f64 } else { 0.0 },
            })
        })
        .collect();

    println!();
    println!("  Transfer Results");
    println!("  ----------------");
    println!("  Overall:      {}/{} transferred ({:.1}%)", transferred_count, total, overall_rate * 100.0);
    println!();
    println!("  Per-category:");
    for (cat, ct) in &category_transfer {
        println!("    {:<32} {}/{} ({:.1}%)  src_avg={:.2} → replay_avg={:.2}",
            cat, ct.transferred, ct.total, ct.rate * 100.0, ct.avg_source_fitness, ct.avg_replay_fitness);
    }
    println!();

    let results = TransferResults {
        source_target: archive.target,
        replay_target: target_str.to_string(),
        source_archive_entries: total,
        overall_success_rate: overall_rate,
        total_transferred: transferred_count,
        category_transfer,
        entries: transfer_entries,
    };

    let json = serde_json::to_string_pretty(&results)?;
    let mut file = File::create(output)?;
    file.write_all(json.as_bytes())?;
    println!("  Results saved to: {}", output);
    println!();

    Ok(())
}

fn main() -> Result<()> {
    // Initialize logging
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env()
                .add_directive("evo_framework=info".parse().unwrap()),
        )
        .init();

    let cli = Cli::parse();

    match cli.command {
        Commands::Llm { action } => match action {
            LlmCommands::Jailbreak {
                target,
                generations,
                population,
                tournament_size,
                mutation_rate,
                crossover_rate,
                seed,
                output,
                verbose,
                judge,
                store_responses,
                map_elites,
                me_bins,
                me_batch_size,
                novelty,
                novelty_weight,
                novelty_k,
                concurrency,
                seeds,
            } => {
                run_jailbreak_evolution(
                    &target,
                    generations,
                    population,
                    tournament_size,
                    mutation_rate,
                    crossover_rate,
                    seed,
                    &output,
                    verbose,
                    judge.as_deref(),
                    store_responses,
                    map_elites,
                    me_bins,
                    me_batch_size,
                    novelty,
                    novelty_weight,
                    novelty_k,
                    concurrency,
                    seeds.as_deref(),
                )?;
            }
            LlmCommands::Transfer {
                archive,
                target,
                judge,
                concurrency,
                output,
            } => {
                run_transfer_replay(
                    &archive,
                    &target,
                    judge.as_deref(),
                    concurrency,
                    &output,
                )?;
            }
        },
        Commands::Analyze { input } => {
            analyze_results(&input)?;
        }
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_target_mock_refuse() {
        let target = parse_target("mock:refuse").unwrap();
        assert_eq!(target.name(), "mock");
    }

    #[test]
    fn test_parse_target_mock_default() {
        let target = parse_target("mock").unwrap();
        assert_eq!(target.name(), "mock");
    }

    #[test]
    fn test_parse_target_mock_comply() {
        let target = parse_target("mock:comply").unwrap();
        assert_eq!(target.name(), "mock");
    }

    #[test]
    fn test_parse_target_openai_missing_key() {
        std::env::remove_var("OPENAI_API_KEY");
        let result = parse_target("openai:gpt-4");
        assert!(result.is_err());
        let err = result.err().unwrap();
        assert!(err.to_string().contains("OPENAI_API_KEY"));
    }

    #[test]
    fn test_parse_target_anthropic_missing_key() {
        std::env::remove_var("ANTHROPIC_API_KEY");
        let result = parse_target("anthropic:claude-sonnet-4-20250514");
        assert!(result.is_err());
        let err = result.err().unwrap();
        assert!(err.to_string().contains("ANTHROPIC_API_KEY"));
    }

    #[test]
    fn test_parse_target_gemini_missing_key() {
        std::env::remove_var("GOOGLE_API_KEY");
        let result = parse_target("gemini:gemini-2.0-flash");
        assert!(result.is_err());
        let err = result.err().unwrap();
        assert!(err.to_string().contains("GOOGLE_API_KEY"));
    }

    #[test]
    fn test_parse_target_ollama() {
        let target = parse_target("ollama:llama3.2").unwrap();
        assert_eq!(target.name(), "llama3.2");
    }

    #[test]
    fn test_parse_target_openai_compat() {
        let target =
            parse_target("openai-compat:google/gemma-7b-it@http://localhost:8000").unwrap();
        assert_eq!(target.name(), "google/gemma-7b-it");

        // Handles HTTPS with port
        let target = parse_target(
            "openai-compat:my-model@https://pod123-8000.proxy.runpod.net",
        )
        .unwrap();
        assert_eq!(target.name(), "my-model");

        // Missing @ separator
        assert!(parse_target("openai-compat:model-without-url").is_err());

        // Empty model
        assert!(parse_target("openai-compat:@http://localhost:8000").is_err());

        // Empty URL
        assert!(parse_target("openai-compat:model@").is_err());
    }

    // Single test that exercises all huggingface: parser branches.
    // Merged to avoid env-var races with other tests running in parallel.
    #[test]
    fn test_parse_target_huggingface() {
        std::env::remove_var("HUGGINGFACE_TOKEN_QAA");
        let result = parse_target("huggingface:google/gemma-7b-it");
        assert!(result.is_err());
        assert!(result.err().unwrap().to_string().contains("HUGGINGFACE_TOKEN_QAA"));

        std::env::set_var("HUGGINGFACE_TOKEN_QAA", "test-key");

        // HF router model IDs may carry a provider suffix after a second ':'.
        // The parser must keep that suffix intact rather than splitting on it.
        let target = parse_target("huggingface:meta-llama/Llama-3-8B:novita").unwrap();
        assert_eq!(target.name(), "meta-llama/Llama-3-8B:novita");

        let result = parse_target("huggingface:");
        assert!(result.is_err());

        std::env::remove_var("HUGGINGFACE_TOKEN_QAA");
    }

    #[test]
    fn test_parse_target_unknown() {
        let result = parse_target("unknown:model");
        assert!(result.is_err());
        let err = result.err().unwrap();
        assert!(err.to_string().contains("Unknown target"));
    }

    #[test]
    fn test_parse_target_invalid_format() {
        let result = parse_target("invalid");
        assert!(result.is_err());
    }

    #[test]
    fn test_attack_result_serialization() {
        let result = AttackResult {
            strategy: "Roleplay".to_string(),
            encoding: "Base64".to_string(),
            secondary_strategy: Some("Encoding".to_string()),
            fitness: 0.75,
            prompt: "test prompt".to_string(),
            generation: 5,
            seed_id: None,
            seed_category: None,
            response: Some("I can help with that".to_string()),
            judge_result: Some(SerializableJudgeResult {
                score: 0.8,
                refused: false,
                harmful_content: true,
                relevant: true,
                explanation: "Test explanation".to_string(),
            }),
        };

        let json = serde_json::to_string(&result).unwrap();
        assert!(json.contains("Roleplay"));
        assert!(json.contains("0.75"));
        assert!(json.contains("I can help"));

        let parsed: AttackResult = serde_json::from_str(&json).unwrap();
        assert_eq!(parsed.strategy, "Roleplay");
        assert!((parsed.fitness - 0.75).abs() < 1e-10);
        assert!(parsed.response.is_some());
        assert!(parsed.judge_result.is_some());
    }

    #[test]
    fn test_attack_result_without_response() {
        let result = AttackResult {
            strategy: "Direct".to_string(),
            encoding: "None".to_string(),
            secondary_strategy: None,
            fitness: 0.5,
            prompt: "test".to_string(),
            generation: 1,
            seed_id: None,
            seed_category: None,
            response: None,
            judge_result: None,
        };

        let json = serde_json::to_string(&result).unwrap();
        // Optional fields should not be present in JSON when None
        assert!(!json.contains("response"));
        assert!(!json.contains("judge_result"));
    }

    #[test]
    fn test_evolution_results_serialization() {
        let results = EvolutionResults {
            target: "mock:comply".to_string(),
            generations: 10,
            population_size: 20,
            best_attack: AttackResult {
                strategy: "DirectJailbreak".to_string(),
                encoding: "None".to_string(),
                secondary_strategy: None,
                fitness: 1.0,
                prompt: "test".to_string(),
                generation: 10,
                seed_id: None,
                seed_category: None,
                response: None,
                judge_result: None,
            },
            top_attacks: vec![],
            category_summary: None,
            config: RunConfig {
                mutation_rate: 0.3,
                crossover_rate: 0.7,
                tournament_size: 3,
                seed: Some(42),
            },
        };

        let json = serde_json::to_string(&results).unwrap();
        assert!(!json.contains("category_summary"));
        let parsed: EvolutionResults = serde_json::from_str(&json).unwrap();

        assert_eq!(parsed.target, "mock:comply");
        assert_eq!(parsed.generations, 10);
        assert_eq!(parsed.config.seed, Some(42));
        assert!(parsed.category_summary.is_none());
    }

    #[test]
    fn test_run_config_serialization() {
        let config = RunConfig {
            mutation_rate: 0.3,
            crossover_rate: 0.7,
            tournament_size: 3,
            seed: None,
        };

        let json = serde_json::to_string(&config).unwrap();
        let parsed: RunConfig = serde_json::from_str(&json).unwrap();

        assert!((parsed.mutation_rate - 0.3).abs() < 1e-10);
        assert!(parsed.seed.is_none());
    }
}
