# Cross-Generational Transfer of Adversarial Attacks

Supplementary code for NeurIPS 2026 submission.

See `supplementary/README.md` for full reproduction instructions.

## Quick Start

```bash
cargo build --release

# Run evolution
cargo run --release -- llm jailbreak \
  --target "openai-compat:google/gemma-7b-it@http://localhost:8000" \
  --judge "openai-compat:meta-llama/Llama-3.1-8B-Instruct@http://localhost:8001" \
  --seeds experiments/seeds/harmbench.jsonl \
  --seed 42 \
  --map-elites --me-bins 6 --me-batch-size 50 --generations 200 \
  --store-responses --concurrency 5 \
  --output results/gemma1_7b/seed_42/results.json

# Regenerate figures
bash supplementary/run_all_analysis.sh
```
