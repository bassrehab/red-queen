# Cross-Generational Transfer of Adversarial Attacks

Supplementary code for "Cross-Generational Transfer of Adversarial Attacks
Reveals Non-Monotonic Safety Alignment in LLMs" (NeurIPS 2026 submission).

See `supplementary/README.md` for full reproduction instructions.

## Quick Start

```bash
# Build
cargo build --release

# Run evolution
cargo run --release -- llm jailbreak \
  --target "openai-compat:google/gemma-7b-it@http://localhost:8000" \
  --judge "openai-compat:meta-llama/Llama-3.1-8B-Instruct@http://localhost:8001" \
  --seeds experiments/seeds/harmbench.jsonl \
  --seed 42 \
  --map-elites --me-bins 6 --me-batch-size 50 --generations 200 \
  --store-responses --concurrency 5 \
  --output results/gemma1_7b/seed_42/results.json

# Run transfer replay
cargo run --release -- llm transfer \
  --archive results/gemma1_7b/seed_42/results_archive.json \
  --target "openai-compat:google/gemma-2-9b-it@http://localhost:8000" \
  --judge "openai-compat:meta-llama/Llama-3.1-8B-Instruct@http://localhost:8001" \
  --concurrency 5 \
  --output results/transfer/gemma1_7b_seed42_on_gemma2_9b.json

# Regenerate figures
bash supplementary/run_all_analysis.sh
```
